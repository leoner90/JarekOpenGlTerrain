#include "Texturing.h"

Texturing::Texturing()
{
}

Texturing::~Texturing()
{
}
