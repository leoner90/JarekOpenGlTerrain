#pragma once

class Texturing
{
public:
	Texturing();
	~Texturing();

private:

};